import java.io.FileWriter;
import java.io.IOException;

import com.fruit.Apple;
import com.fruit.Mango;

public class Main{
      public static void main(String[] args) throws InterruptedException, IOException {
            Mango mango1 = new Mango("Mango", "yellow", 80);
            Mango mango2 = new Mango("Mango", "yellow", 100);
            Mango mango3 = new Mango("Mango", "yellow", 150);
            Apple apple1 = new Apple("Apple", "Red", 200);
            Apple apple2 = new Apple("Apple","Red", 250);



            Retailer r1 = new Retailer("Jaganna",23);
            UrbanFarmer uf1 = new UrbanFarmer("Bomkesha",(short)26);

            FileWriter fw=new FileWriter("output1.txt");
            uf1.harvest(mango1);
            fw.write("harvested 1\n");
            r1.buy();
            fw.write("purchased 1\n");
            uf1.harvest(mango2);
            fw.write("harvested 2\n");
            r1.buy();
            fw.write("purchased 2\n");
            uf1.harvest(mango3);
            fw.write("harvested 3\n");
            r1.buy();
            fw.write("purchased 3\n");

            uf1.harvest(apple1);
            fw.write("harvested 4\n");
            r1.buy();
            fw.write("purchased 4\n");

            uf1.harvest(apple2);
            fw.write("harvested 5\n");
            r1.buy();
            fw.write("purchased 5");
fw.close();
      }
}